<form role="search" method="get" id="searchform-content" action="<?php echo esc_url(home_url('/')); ?>">
        <input type="text" value="" name="s" class="search-content-input"
               placeholder="<?php _e('Search', 'harmonux'); ?>">
        <input type="submit" class="searchsubmit-content" value="<?php _e('Search', 'harmonux'); ?>">
</form>