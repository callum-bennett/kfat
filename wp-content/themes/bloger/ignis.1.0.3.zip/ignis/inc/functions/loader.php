<?php

/**
 * Load function files
 *
 * @package Talon
 */


require get_template_directory() . '/inc/functions/functions-header.php';
require get_template_directory() . '/inc/functions/functions-footer.php';
require get_template_directory() . '/inc/functions/functions-blog.php';